#______________________________________________________________________________________________________________________________________________________
import pygame as pg
import numpy as np
import math as m

pg.init()

def text(t,p,c,s):
	font=pg.font.Font(None,s)
	txt=font.render(t,True,c)
	sc.blit(txt,p)
	
def poco(p):
	return np.add(np.multiply(np.add(center,(scw/2/zoom,sch/2/zoom)),zoom),np.multiply((p[0],-p[1]),zoom))
	
def grid(sc):
	x=pos[0]
	y=pos[1]
	if zoom>0.5:
		n1=100
	elif zoom>0.05:
		n1=1000
	else:
		n1=10000
	n=n1*zoom
	xn=m.floor((scw+(x/n-x//n)*n)/n)
	yn=m.floor((sch+(y/n-y//n)*n)/n)
	for i in range(xn):
		x1=(x/n-x//n)*n+i*n
		pg.draw.line(sc,((100,100,100) if m.floor(x1-x)!=0 else (0,0,255)),(x1,0),(x1,sch),1)
	for i in range(yn):
		y1=(y/n-y//n)*n+i*n
		pg.draw.line(sc,((100,100,100) if m.floor(y1-y)!=0 else (0,255,0)),(0,y1),(scw,y1),1)
		
class controls:
	def __init__(self):
		zoom_in_img=pg.image.load('zoom_in.png').convert()
		zoom_out_img=pg.image.load('zoom_out.png').convert()
		
		self.in_surf=pg.transform.scale(zoom_in_img,(50,50))
		self.out_surf=pg.transform.scale(zoom_out_img, (50,50))
		self.in_rect=self.in_surf.get_rect(topleft=(10,100))
		self.out_rect=self.out_surf.get_rect(topleft=(10,160))
		
		self.buff=[]
		self.bull=[]
		
		w=sc.get_width()
		h=sc.get_height()
		
		self.slider=pg.surface.Surface((60,40))
		self.slider.fill((0,255,0))
		self.sliderp=(w/2,h-50)
		self.slider_rect=self.slider.get_rect(center=self.sliderp)
		self.slidec=0
		self.slidec1=0
		self.b=True
	def update(self,pbuff):
		global zoom
		for e in event:
			if e.type==pg.FINGERDOWN:
				x=round(scw*e.x)
				y=round(sch*e.y)
				
				if self.in_rect.collidepoint((x,y)):
					self.buff.append(e.finger_id)
					self.bull.append('in')
				if self.out_rect.collidepoint((x,y)):
					self.buff.append(e.finger_id)
					self.bull.append('out')
				if self.slider_rect.collidepoint((x,y)):
					self.buff.append(e.finger_id)
					self.bull.append('slide')
					#if self.b:
					#	self.slider_rect=self.slider.get_rect(center=(x,self.sliderp[1]))
					#	self.slidec=(x-self.sliderp[0])/300
					self.b=False
					
				if self.buff.count(e.finger_id)==0:
					self.buff.append(e.finger_id)
					self.bull.append('swipe')
				
			if e.type==pg.FINGERMOTION:
				x=scw*e.x
				y=sch*e.y
				for i in range(len(self.buff)):
					dx=e.dx
					dy=e.dy
					if self.bull[i]=='swipe':
						dx1=scw*e.dx/zoom
						dy1=sch*e.dy/zoom
						center[0]+=dx1
						center[1]+=dy1
					if self.bull[i]=='slide':
						ind=self.bull.index('slide')
						if e.finger_id==self.buff[ind]:
							self.slidec1+=dx*scw
							self.slidec=self.slidec1/600
							self.slider_rect=self.slider.get_rect(center=(self.sliderp[0]+self.slidec1,self.sliderp[1]))
							
			if e.type==pg.FINGERUP:
				x=scw*e.x
				y=sch*e.y
				
				ind=self.buff.index(e.finger_id)
				self.buff.remove(e.finger_id)
				if self.bull[ind]=='slide':
				#	self.slider_rect=self.slider.get_rect(center=self.sliderp)
					self.slidec=0
					self.b=True
				self.bull.pop(ind)
		
		for i in range(len(self.buff)):
			if self.bull[i]=='in':
				zoom+=0.03*zoom*60/fps
			if self.bull[i]=='out':
				if zoom>0.01:
					zoom-=0.03*zoom*60/fps
		
		if self.bull.count('slide')==0:
			self.slidec1=pbuff*600
			self.slidec=0
			self.slider_rect=self.slider.get_rect(center=(self.sliderp[0]+self.slidec1,self.sliderp[1]))
			
		
	def show(self):
		sc.blit(self.in_surf,self.in_rect)
		sc.blit(self.out_surf,self.out_rect)
		sc.blit(self.slider,self.slider_rect)
		text(f'{self.buff} {self.bull}',(10,300),'white',35)

def liftc(t): #RADIANS 0 to 2pi (Negative is accepted)
	b=False
	b1=False
	if t<0:
		t=-t
		b1=True
	if t>m.pi/2:
		t=m.pi-t
		b=True
	if t<15*m.pi/180:
		l=m.sin(m.pi/2*t/(15*m.pi/180))*1.1
	elif t<20*m.pi/180:
		l=m.cos(m.pi*(t-15*m.pi/180)/(5*m.pi/180))/4+.85
	elif t<m.pi/4:
		l=m.sin(m.pi/2*(t-20*m.pi/180)/(25*m.pi/180))/2*.9+.6
	elif t<=m.pi/2:
		l=m.cos(m.pi/2*(t-m.pi/4)/(m.pi/4))*1.05
	else:
		l=0
	if b1:
		l=-l
	if b:
		l=-l
	return l
	
def dragc(t):
	if t<0:
		t=-t
		b=True
	if t>m.pi/2:
		t=m.pi-t
	if t<m.pi/3:
		l=m.sin(t)*m.sin(m.pi/2*t/(m.pi/3))**2
	elif t<=m.pi/2:
		l=m.sin(t)
	else:
		l=0
	return l

def density(h):
	if h<11000: #11km
		t=15.04-.00649*h #celcius
		p=101.29*((t+273.1)/288.08)**5.256
	elif h<25000:
		t=-56.46
		p=22.65*m.e**(1.73-.000157*h)
	elif h>=25000:
		t=-131.21+.00299*h
		p=2.488*((t+273.1)/216.6)**-11.388
	d=p/(.2869*(t+273.1))
	return d

def v2rad(p):
	r=m.sqrt(np.sum(np.square(p)))
	if r>0:
		c=m.acos(p[0]/r)
		rc=m.pi-c
		n=1 if p[1]<0 else 0
		rad=c+2*rc*n
		return rad
	else:
		return 0

class missile:
	def __init__(self,position,Acceliration):
		self.bcoef=0
		self.image=pg.image.load('missile.png').convert()
		self.image.set_colorkey((0,255,0))
		self.velocity=0
		self.width=(12+34)/100 #m
		self.height=3 #m
		self.width1=(12+34) #cm
		self.height1=300 #cm
		self.wing_span=.17 #m
		self.fin_span=.17 #m
		self.wing_pos=.6 #m
		self.fin_pos=-1.2 #m
		self.wp=60 #cm
		self.fp=-120 #cm
		self.cm=0 #m #Center Mass
		self.wing_area=self.wing_span**2*(1+1/2)
		self.fin_area=self.fin_span**2*(2+1/2)
		self.mass=85.3 #kg
		self.inertia=1/12*self.mass*(self.height)**2
		self.position=position
		self.vel=[0,0]
		self.angle=90
		self.av=0 #angular velocity
		self.accel=Acceliration #Acceleration
		self.wing_rad=0
		self.fin_rad=0
		self.kfc=0.4
		self.sfc=0.6
		self.flamep=[]
		self.flamel=10
		self.rad=self.angle*m.pi/180
		self.buff=0
		self.buff1=[0,0,0]
		self.boo=False
		self.count=0
		for i in range(self.flamel):
			self.flamep.append(np.add(self.position,(-135*m.cos(self.rad),-135*m.sin(self.rad))))
		
	def update(self,fps,pitch):
		
		if self.angle>360:
			self.angle-=360*m.floor(self.angle/360)
		elif self.angle<0:
			self.angle+=360*m.ceil(-self.angle/360)
		self.rad=self.angle*m.pi/180
		
		self.lines=[]
		#NORMAL SCALE
		self.surf=pg.transform.scale(self.image,(self.width1,self.height1))
		self.surf=pg.transform.rotate(self.surf,self.angle-90)
		self.rect=self.surf.get_rect(center=self.position)
		
		#VELOCITY
		velocity=m.sqrt(np.sum(np.square(self.vel)))
		self.vv=velocity
		
		#ANGLE
		unit_rad=(m.cos(self.rad),m.sin(self.rad))
		if velocity>0:
			vrad=v2rad(self.vel)
			self.vr=vrad
			unit_vrad=(m.cos(vrad),m.sin(vrad))
			#Drad=m.acos(np.dot(unit_rad,self.vel)/(velocity))
			sr=self.rad
			vr=vrad
			Drad1=sr-vr-(2*m.pi if sr-vr>m.pi/2 else (-2*m.pi if sr-vr<-m.pi/2 else 0))
			Drad=abs(Drad1)
	#		text(f'diff_angle={round(Drad*180/m.pi)},v={round(velocity*60*60/1000,2)}km/h,vrad={round(vrad*180/m.pi)},rad={round(self.rad*180/m.pi)}',(100,1050),'white',30)
		#DRAG and LIFT
			wing_drag=1/2*dragc((Drad1+self.wing_rad))*density(self.position[1]/100)*((self.wing_area*2)*m.sin((Drad1+self.wing_rad)))*velocity**2
			fin_drag=1/2*dragc((Drad1+self.fin_rad))*density(self.position[1]/100)*((self.fin_area*2)*m.sin((Drad1+self.fin_rad)))*velocity**2
			wing_lift=1/2*liftc((Drad1+self.wing_rad))*density(self.position[1]/100)*self.wing_area*2*velocity**2
			fin_lift=1/2*liftc((Drad1+self.fin_rad))*density(self.position[1]/100)*self.fin_area*2*velocity**2
			body_drag=1/2*dragc(Drad)*density(self.position[1]/100)*(self.width**2*m.cos(Drad)+self.width*self.height*m.sin(Drad))*velocity**2
		else:
			wing_drag=0
			fin_drag=0
			wing_lift=0
			wing_lift=0
	#	text(f'wing_drag={round(wing_drag)}N,fin_drag={round(fin_drag)}N',(100,1100),'white',30)
		
		#ANGULAR dynamics
		if velocity>0:
			a1=wing_drag*abs(m.sin(Drad1))
			a2=-fin_drag*abs(m.sin(Drad1))
			a3=wing_lift*(abs(m.sin(m.pi/2+Drad*(1 if Drad1<0 else -1))))
			a4=-fin_lift*(abs(m.sin(m.pi/2+Drad*(1 if Drad1<0 else -1))))
			a1v=a1*abs(self.wing_pos-self.cm)/self.inertia
			a2v=a2*abs(self.fin_pos-self.cm)/self.inertia
			a3v=a3*abs(self.wing_pos-self.cm)/self.inertia
			a4v=a4*abs(self.fin_pos-self.cm)/self.inertia
	#		text(f'a1={round(a1,2)},a2={round(a2,2)},a3={round(a3,2)},a4={round(a4,2)}',(100,1250),'white',30)
			if (self.av+(a1v+a2v+a3v+a4v)/fps>0 and self.av<0) or (self.av+(a1v+a2v+a3v+a4v)/fps<0 and self.av>0):
				self.av=0
				self.boo=True
				self.count=0
			elif self.boo:
				self.count+=1
				self.av+=(a1v+a2v+a3v+a4v)/1000
				if self.count>1:
					self.boo=False
					self.count=0
			else:
				self.av+=(a1v+a2v+a3v+a4v)/fps
			if self.fin_rad==m.pi*1/12:
				aav=(a1v+a2v+a3v+a4v)
			#if abs(self.av)<m.pi/100:
#				self.av=0
			
			# ROTATIONAL DRAG
			avw=abs(self.av)*(self.wing_pos-self.cm)
			avf=abs(self.av)*(self.fin_pos-self.cm)
			wd=1/2*dragc(self.wing_rad+m.pi/2)*density(self.position[1]/100)*(self.wing_area*m.cos(self.wing_rad))*(avw**2)
			fd=1/2*dragc(self.fin_rad+m.pi/2)*density(self.position[1]/100)*(self.fin_area*m.cos(self.fin_rad))*(avf**2)
			aanet=(wd*(self.wing_pos-self.cm)/self.inertia+fd*(self.fin_pos-self.cm)/self.inertia)*(1 if self.av>0 else -1)
			self.av+=aanet/fps
	#		text(f'aanet={round(aanet,2)}, {[round(wd,4),round(fd,4)]}, a={round(self.angle,2)}',(100,1200),'white',30)
			
			self.angle+=self.av*180/m.pi/fps
			
			self.lines.append(('blue',(100*m.cos(self.rad+self.fin_rad),-100*m.sin(self.rad+self.fin_rad)),1,1))
			self.lines.append(((0,255,100),(100*m.cos(self.rad+self.wing_rad),-100*m.sin(self.rad+self.wing_rad)),0,1))
			self.lines.append(('red',(25*m.cos(self.rad+m.pi/2+self.wing_rad),-25*m.sin(self.rad+m.pi/2+self.wing_rad)),0,0))
			self.lines.append(('red',(25*m.cos(self.rad+m.pi/2+self.fin_rad),-25*m.sin(self.rad+m.pi/2+self.fin_rad)),1,0))
			self.lines.append(('red',(25*m.cos(self.rad-m.pi/2+self.wing_rad),-25*m.sin(self.rad-m.pi/2+self.wing_rad)),0,0))
			self.lines.append(('red',(25*m.cos(self.rad-m.pi/2+self.fin_rad),-25*m.sin(self.rad-m.pi/2+self.fin_rad)),1,0))
			
			#VELOCITY1
			v1=-wing_drag/self.mass/fps*m.cos(vrad+self.wing_rad)-fin_drag/self.mass/fps*m.sin(vrad+self.fin_rad)
			v2=abs(wing_lift)/self.mass/fps*m.cos((vrad+m.pi/2 if Drad1>0 else vrad-m.pi/2)+self.wing_rad)+abs(fin_lift)/self.mass/fps*m.sin((vrad+m.pi/2 if Drad1>0 else vrad-m.pi/2)+self.fin_rad)
			self.vel=np.add(self.vel,(v1,v1))
			self.vel=np.add(self.vel,(v2,v2))
			v3=self.accel/fps
			self.vel=np.add(self.vel,np.multiply(v3,(m.cos(self.rad),m.sin(self.rad))))
			v4=-body_drag/self.mass/fps
			self.vel=np.add(self.vel,np.multiply(v4,(m.cos(vrad),m.sin(vrad))))
			
	#		text(f'av={round(self.av*180/m.pi,2)},{[round(a1,2),round(a2,2)]},{round(a1v+a2v,2)}',(100,1150),'white',30)
		
		#PITCH
		if pitch==0 and velocity>0:
			if self.buff1[1]>1:
				self.buff-=self.buff1[0]
				self.buff1[1]-=1
				self.buff1[2]-=self.buff1[3]
			else:
				self.buff=0
			self.fin_rad=self.buff
		else:
			self.fin_rad=m.pi/2*pitch
			self.buff=self.fin_rad
			tbuff=1
			self.buff1=[self.buff/(tbuff*fps),m.floor(tbuff*fps),pitch,pitch/(tbuff*fps)]
		if velocity>0:
			self.wing_per=-((self.av)/(1+velocity*.0001) if abs((self.av)/(1+velocity*.0001))<m.pi/4/(1+velocity*.0001) else m.pi/4/(1+velocity*.0001)*(1 if (self.av+aanet/fps)>0 else -1))*(1 if abs(Drad1)<m.pi/2 else -1)*(0 if abs(Drad1)<0.01 else 1)
			if abs(self.wing_per-self.wing_rad)>5*m.pi/fps:
				self.wing_rad+=5*m.pi/fps*(1 if self.wing_per-self.wing_rad>0 else -1)
			else:
				self.wing_rad=self.wing_per
		
		# GRAVITY
		if self.position[1]-self.rect.height/2>0:
			self.vel[1]-=gravity/fps
		elif self.position[1]-self.rect.height/2<0:
			self.vel[1]=-self.vel[1]*self.bcoef
			self.position[1]=+self.rect.height/2
			self.av=-0.0000000001*self.av
		elif gravity*self.sfc<abs(self.vel[0]):
			self.vel[0]+=gravity*self.kfc*(1 if self.vel[0]<0 else -1)
		else:
			self.vel[0]=0
		
		#DISPLACEMENT
		self.position=np.add(self.position,(self.vel[0]/fps*100,self.vel[1]/fps*100)) #cm to m
		
		self.velocity=velocity
		
	def show(self):
		
		self.surf=pg.transform.scale(self.image,(round(self.width1*zoom),round(self.height1*zoom)))
		self.surf=pg.transform.rotate(self.surf,self.angle-90)
		self.rect=self.surf.get_rect(center=poco(self.position))
#		pg.draw.rect(sc,'blue',self.rect)
		
		if self.vv>0:
			pg.draw.line(sc,(0,255,255),self.rect.center,np.add(self.rect.center,(300*m.cos(self.vr),-300*m.sin(self.vr))),3)
		
		sc.blit(self.surf,self.rect)
#		pg.draw.circle(sc,'red',self.rect.center,3)
#		pg.draw.circle(sc,'red',np.add(self.rect.center,(self.wp*m.cos(self.rad),-self.wp*m.sin(self.rad))),3)
#		pg.draw.circle(sc,'red',np.add(self.rect.center,(self.fp*m.cos(self.rad),-self.fp*m.sin(self.rad))),3)
		wp=np.add(self.rect.center,(self.wp*m.cos(self.rad)*zoom,-self.wp*m.sin(self.rad)*zoom))
		fp=np.add(self.rect.center,(self.fp*m.cos(self.rad)*zoom,-self.fp*m.sin(self.rad)*zoom))
		if self.vv>0:
			for c,p,b,b1 in self.lines:
				if b==0 and (zoom>0.05 or b1==1):
					pg.draw.line(sc,c,wp,np.add(wp,p),3)
				if b==1 and (zoom>0.05 or b1==1):
					pg.draw.line(sc,c,fp,np.add(fp,p),3)
		self.flamep.append(np.add(self.position,(-135*m.cos(self.rad),-135*m.sin(self.rad))))
		self.flamep.pop(0)
		npos=[]
		for i in range(len(self.flamep)):
			npos.append(poco(self.flamep[i]))
		pg.draw.lines(sc,'#FAC000',False,npos,5)
		
sc=pg.display.set_mode()
scw=sc.get_width()
sch=sc.get_height()
clock=pg.time.Clock()

center=[0,0]

ctrl=controls()
zoom=1

gravity=9.81

pts=[]
for i in range(181):
	n=i*m.pi/180
	pts.append((i+100,-liftc(n)*180+600))


pts1=[]
for i in range(181):
	n=i*m.pi/180
	pts1.append((i+100,-dragc(n)*180+600))
	
pts2=[]
for i in range(500):
	n=i*100
	pts2.append((i+100,800-density(n)*180))










# HEY!, YOU CAN CHANGE THIS

Acceleration=30 #m^2/s






m1=missile([100,200],Acceleration)

while 1:
	fps=clock.get_fps()
	if fps==0:
		fps=10**10
	
	event=pg.event.get()
	
	pos=np.multiply(np.add(center,(scw/2/zoom,sch/2/zoom)),zoom)
	
	sc.fill('black')
	grid(sc)
	text(f'x:{round(center[0]/100000,2)}km altitude:{round(center[1]/100000,2)}km     {"in Atmosphere" if center[1]/100000<100 else "above Karman Line"}',(10,40),'white',35)
	
	ctrl.update(m1.buff1[2])
	m1.update(fps,ctrl.slidec)
	center=np.multiply(m1.position,(-1,1))
	m1.show()
	
	# LIFT COEF, DRAG COEF, DENSITY {GRAPH} (remove # to display)
#	pg.draw.lines(sc,(0,255,255),False,pts,1)
#	pg.draw.lines(sc,(255,0,0),False,pts1,1)
#	pg.draw.lines(sc,(0,255,255),False,pts2,1)
	
	ctrl.show()
	
	text(f'mach:{m.floor(m1.velocity*.00081*10)/10} velocity:{m.floor(m1.velocity)}km/h air_density:{round(density(m1.position[1]/100),4)}kg/m^3',(scw-600,10),'white',30)
	
	
	text("drag this green to left or right to control the missile",(100,sch-100),"white",30)
	text(f'fps[{round(fps)}]',(10,10),(0,255,0),30)
	pg.display.update()
	clock.tick(1000)




