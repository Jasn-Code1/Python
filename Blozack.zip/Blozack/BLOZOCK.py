import pygame as py
import numpy as np
import math as m
from sys import exit
from pygame.locals import *

py.init()

def text(t,c,x,y,s):
	font=py.font.Font(None,s)
	text=font.render(t,True,c)
	sc.blit(text,(x,y))
	
def text1(t,c,x,y,s):
	font=py.font.Font(None,s)
	font.set_underline(True)
	font.set_italic(True)
	text=font.render(t,True,c)
	sc.blit(text,(x,y))

class rectangle(py.sprite.Sprite):
	def __init__(self,c,s,p,edge,br):
		super().__init__()
		self.img=py.surface.Surface(s)
		self.rect=self.img.get_rect(topleft=p)
		self.c=c
		self.e=edge
		self.br=br
	def update(self,pos):
		self.rect=self.img.get_rect(topleft=pos)
	def show(self):
		py.draw.rect(sc,self.c,self.rect,self.e,border_radius=self.br)
		
class dotplayer():
	def __init__(self,c,p,r):
		self.c=c
		self.p=p
		self.r=r
		self.sc=(self.p[0]+710,self.p[1]+355)
	def update(self,dp):
		self.p=(self.p[0]+dp[0],self.p[1]+dp[1])
		self.sc=(self.p[0]+710,self.p[1]+355)
	def show(self):
		py.draw.circle(sc,self.c,self.sc,self.r)
		
class joystick(py.sprite.Sprite):
	def __init__(self,c,r):
		super().__init__()
		img=py.surface.Surface((710,670))
		self.rect=img.get_rect(topleft=(0,0))
		self.bobo=False
		self.fid=None
		self.c=c
		self.ra=r
		self.a=0
		self.cos=m.cos(self.a*m.pi/180)
		self.sin=m.sin(self.a*m.pi/180)
		self.xi=0
		self.xi1=0
	def update(self,even):
		for e in even:
			if e.type==FINGERDOWN:
				x=int(e.x*sc.get_width())
				y=int(e.y*sc.get_height())
				if self.rect.collidepoint(x,y):
					self.bobo=True
					self.fid=e.finger_id
					self.xi,self.yi=x,y
					self.xi1,self.yi1=x,y
			if e.type==py.FINGERMOTION:
				x=int(e.x*sc.get_width())
				y=int(e.y*sc.get_height())
				if self.bobo and self.fid==e.finger_id:
					self.xi1,self.yi1=x,y
			if e.type==py.FINGERUP:
				if self.fid==e.finger_id:
					self.bobo=False
		if self.bobo:
			dx=self.xi1-self.xi
			dy=self.yi1-self.yi
			self.r=m.sqrt(dx**2+dy**2)
			
			if self.r>0:
				xa=m.acos(dx/self.r)*180/m.pi
				rxa=m.acos(-dx/self.r)*180/m.pi
				if dy>0:
					by=1
				else:
					by=0
				self.a=xa+rxa*by*2
				self.cos=m.cos(self.a*m.pi/180)
				self.sin=m.sin(self.a*m.pi/180)
				text(f'angle={round(self.a)}','White',0,0,30)
			py.draw.circle(sc,self.c,(self.xi,self.yi),self.ra/4)
			py.draw.circle(sc,self.c,(self.xi+dx/4,self.yi+dy/4),self.ra/3)
			py.draw.circle(sc,self.c,(self.xi+dx/2,self.yi+dy/2),self.ra/2)
			py.draw.circle(sc,self.c,(self.xi+3*dx/4,self.yi+3*dy/4),3*self.ra/4)
			py.draw.circle(sc,self.c,(self.xi1,self.yi1),self.ra)
			
class button():
	def __init__(self,c,c1,s,p):
		self.img=py.surface.Surface(s)
		self.img.fill(c1)
		self.img1=py.surface.Surface((s[0]*(0.8+(1-0.8)*(1-s[1]/s[0])),s[1]*0.8))
		self.img1.fill(c)
		self.rect=self.img.get_rect(center=p)
		self.boo=False
		self.ispressed=False
		self.s=s
		self.p=p
	def show(self):
		self.ispressed=False
		for e in events:
			if e.type==FINGERDOWN:
				x=e.x*sc.get_width()
				y=e.y*sc.get_height()
				if self.rect.collidepoint(x,y):
					self.boo=True
			if e.type==FINGERUP:
				x=e.x*sc.get_width()
				y=e.y*sc.get_height()
				if self.boo and self.rect.collidepoint(x,y):
					self.ispressed=True
				self.boo=False
		sc.blit(self.img,self.rect)
		sc.blit(self.img1,(self.rect.x+self.s[0]*(0.1/(self.s[0]/self.s[1])),self.rect.y+self.s[1]*0.1))
		
class imgbutton():
	def __init__(self,path,c1,s,p):
		self.img=py.surface.Surface(s)
		self.img.fill(c1)
		self.img1=py.image.load(path).convert()
		self.img1=py.transform.scale(self.img1,(int(s[0]*(0.8+(1-0.8)*(1-s[1]/s[0]))),int(s[1]*0.8)))
		self.rect=self.img.get_rect(center=p)
		self.boo=False
		self.ispressed=False
		self.isdown=False
		self.s=s
		self.p=p
	def show(self):
		self.ispressed=False
		self.isdown=False
		for e in events:
			if e.type==FINGERDOWN:
				x=e.x*sc.get_width()
				y=e.y*sc.get_height()
				if self.rect.collidepoint(x,y):
					self.boo=True
					self.isdown=True
			if e.type==FINGERUP:
				x=e.x*sc.get_width()
				y=e.y*sc.get_height()
				if self.boo and self.rect.collidepoint(x,y):
					self.ispressed=True
				self.boo=False
		sc.blit(self.img,self.rect)
		sc.blit(self.img1,(self.rect.x+self.s[0]*(0.1/(self.s[0]/self.s[1])),self.rect.y+self.s[1]*0.1))
		
class char(py.sprite.Sprite):
	def __init__(self,s,r):
		super().__init__()
		self.a=250
		self.a1=0
		self.r=r
		self.p=1
		self.p1=1
		self.s=s
		self.img=py.image.load('Charac/char.png').convert()
		self.img1=py.image.load('Charac/blink.png').convert()
		self.img2=py.image.load('Charac/iris.png').convert_alpha()
		self.img3=py.image.load('Charac/mouth.png').convert_alpha()
		self.img4=py.image.load('Charac/Wmouth.png').convert_alpha()
		self.img5=py.image.load('Charac/yawn.png').convert_alpha()
		self.outl=py.surface.Surface((s[0]+r,s[1]+r))
		self.outl.fill('White')
		self.img=py.transform.scale(self.img,s)
		self.img1=py.transform.scale(self.img1,s)
		self.img2=py.transform.scale(self.img2,s)
		self.img3=py.transform.scale(self.img3,s)
		self.img4=py.transform.scale(self.img4,s)
		self.img5=py.transform.scale(self.img5,s)
		self.rect=self.img.get_rect()
	def show(self,pos):
		self.rect=self.img.get_rect(midbottom=pos)
		sc.blit(self.outl,(self.rect[0]-self.r/2,self.rect[1]-self.r/2))
		if self.a>480:
			sc.blit(self.img1,self.rect)
			if self.p1==5:
				sc.blit(self.img5,self.rect)
			else:
				sc.blit(self.img3,self.rect)
		else:
			if self.p==4:
				if self.a>320:
					sc.blit(self.img1,self.rect)
				else:
					sc.blit(self.img,self.rect)
			elif self.p==5:
				if self.a>20 and self.a<=40:
					sc.blit(self.img1,self.rect)
				else:
					sc.blit(self.img,self.rect)
			else:
				sc.blit(self.img,self.rect)
			#____________
			ra=(self.s[0]/100)
			if self.a>70 and self.p==2:
				if self.a1<6*ra:
					self.a1+=0.5*ra
				elif self.a>150 and self.a<=151:
					self.a1=0
					self.p1=2
				elif self.a>300 and self.a<=301:
					self.a1=0
					self.p1=3
				
				if self.p1==1:
					sc.blit(self.img2,(self.rect[0]+self.a1,self.rect[1]+self.a1/3))
				elif self.p1==2:
					sc.blit(self.img2,(self.rect[0]+6*ra,self.rect[1]+6/3-self.a1/(1.5*ra)))
				elif self.p1==3:
					sc.blit(self.img2,(self.rect[0]+6*ra-self.a1*2,self.rect[1]-6*ra/3))
				sc.blit(self.img3,self.rect)
				
			elif self.a>70 and self.p==4:
				if self.a1<6*(self.s[0]/100):
					self.a1+=0.5*(self.s[0]/100)
				elif self.a>120 and self.a<=121:
					self.a1=0
					self.p1=2
				elif self.a>133 and self.a<=134:
					self.a1=0
					self.p1=3
				elif self.a>173 and self.a<=174:
					self.a1=0
					self.p1=4
				elif self.a>213 and self.a<=214:
					self.a1=0
					self.p1=5
				elif self.a>300 and self.a<=301:
					self.p1=6
					
				if self.p1==1:
					sc.blit(self.img2,(self.rect[0]+self.a1,self.rect[1]))
					sc.blit(self.img3,self.rect)
				elif self.p1==2:
					sc.blit(self.img2,(self.rect[0]+6*ra-self.a1,self.rect[1]))
					sc.blit(self.img3,self.rect)
				elif self.p1==3:
					sc.blit(self.img2,(self.rect[0]-self.a1,self.rect[1]))
					sc.blit(self.img3,self.rect)
				elif self.p1==4:
					sc.blit(self.img2,(self.rect[0]-6*ra+self.a1,self.rect[1]))
					sc.blit(self.img4,self.rect)
				elif self.p1==5:
					sc.blit(self.img2,self.rect)
					sc.blit(self.img4,self.rect)
				elif self.p1==6:
					if self.a<=320:
						sc.blit(self.img2,self.rect)
					sc.blit(self.img5,self.rect)
			
			elif self.p==5:
				if self.a<=20 or self.a>40:
					sc.blit(self.img2,self.rect)
				sc.blit(self.img3,self.rect)
				
			else:
				sc.blit(self.img2,self.rect)
				sc.blit(self.img3,self.rect)
				self.a1=0
				self.p1=1	
			#____________
			
		if self.a>=520:
			self.a=0
			self.p+=1
		if self.p>=6:
			self.p=2
		self.a+=1
			
class charlight():
	def __init__(self,s):
		self.light=py.image.load('Envi/light1.png').convert()
		self.dark=py.surface.Surface((1420,670))
		self.dark.fill((100,100,100))
		if s!=0:
			self.light=py.transform.scale(self.light,(s))
	def show(self,pos):
		self.rect=self.light.get_rect(center=pos)
		self.dark.blit(self.light,self.rect)
		sc.blit(self.dark,(0,0),special_flags=py.BLEND_RGB_SUB)
		
class collidesprirect(py.sprite.Sprite):
	def __init__(self,s):
		super().__init__()
		self.s=s
		self.col=py.surface.Surface((s[0]/2,s[1]/2))
		self.rect=self.col.get_rect()
	def update(self,pos):
		if Joystick.cos>0:
			self.rect=self.col.get_rect(bottomleft=(pos[0],pos[1]-self.s[1]/4))
		elif Joystick.cos<0:
			self.rect=self.col.get_rect(bottomright=(pos[0],pos[1]-self.s[1]/4))
			
class collidesprirectY(py.sprite.Sprite):
	def __init__(self,s):
		super().__init__()
		self.s=s
		self.col=py.surface.Surface((s[0]/2,s[1]/2))
		self.rect=self.col.get_rect()
	def update(self,pos):
		if vel[1]>0:
			self.rect=self.col.get_rect(midtop=(pos[0],pos[1]-self.s[1]))
		elif vel[1]<0:
			self.rect=self.col.get_rect(midbottom=pos)
			
class sign(py.sprite.Sprite):
	def __init__(self,t):
		super().__init__()
		self.stand=py.surface.Surface((10,30))
		self.board=py.surface.Surface((50,25))
		self.stand.fill((50,50,50))
		self.board.fill('White')
		self.t=t
	def show(self,pos):
		self.standrect=self.stand.get_rect(midbottom=pos)
		self.boardrect=self.board.get_rect(midbottom=(pos[0],pos[1]-30))
		sc.blit(self.stand,self.standrect)
		sc.blit(self.board,self.boardrect)
		py.draw.line(sc,'Black',(pos[0]-20,pos[1]-50),(pos[0]+20,pos[1]-50),3)
		py.draw.line(sc,'Black',(pos[0]-20,pos[1]-40),(pos[0]+20,pos[1]-40),3)
		if self.boardrect.colliderect(Char.rect):
			py.draw.rect(sc,'White',(((self.boardrect.midtop[0]-150,self.boardrect.midtop[1]-150),(300,100))),width=0,border_radius=20)
			text(self.t[0],'Black',self.boardrect.midtop[0]-130,self.boardrect.midtop[1]-130,25)
			text(self.t[1],'Black',self.boardrect.midtop[0]-130,self.boardrect.midtop[1]-100,25)
			
clock=py.time.Clock()
sc=py.display.set_mode((1420,670))
bg=py.surface.Surface((1420,670))
bg.fill('Black')
bg1=py.image.load('Envi/bg.png').convert()
bg1=py.transform.scale(bg1,(1420,670))
bg2=py.image.load('Envi/bg2.jpg').convert()
bg2=py.transform.scale(bg2,(1420,670))
CollideGroup=py.sprite.Group()
rect=rectangle('Green',(600,600),(410,35),5,10)
pl=dotplayer('White',(0,0),5)
JG=py.sprite.Group()
Joystick=joystick('White',20)
JG.add(Joystick)
Button=button('Yellow','White',(200,50),(710,235))
Button1=button('Yellow','White',(200,50),(710,305))
Char=char((75,75),2)
introChar=char((200,200),4)
introLight=charlight((1420,1420))
CharLight=charlight((750,750))
introfloor=rectangle((100,100,100),(1420,20),(0,400),0,0)
introfloor1=rectangle((50,50,50),(1420,250),(0,420),0,0)
floor=rectangle((50,50,50),(1420,170),(0,500),0,0)
floor1=rectangle((20,20,20),(1420,10),(0,500),0,0)
CollideGroup.add(floor1)
wall=rectangle((100,100,100),(900,1000),(-900,-500),0,0)
wall1=rectangle((50,50,50),(10,1000),(300,-500),0,0)
CollideGroup.add(wall1)
floor2=rectangle('White',(500,10),(700,300),0,0)
floor3=rectangle('White',(300,10),(1800,100),0,0)
floor4=rectangle((150,150,150),(200,10),(2800,300),0,0)
wall2=rectangle('White',(10,400),(2100,100),0,0)
CollideGroup.add(floor2)
CollideGroup.add(floor3)
CollideGroup.add(floor4)
CollideGroup.add(wall2)
jumpBut=imgbutton('Cont/jump.png','White',(80,80),(1250,500))
Sign=sign(['We need to find the source','to get the lights back.'])
colrect=collidesprirect((75,75))
colrectY=collidesprirectY((75,75))

def collide(r,r2):
	if py.sprite.spritecollide(r,r2,False):
		return True
	else:
		return False

grav=30
vel=(0,0)

page=0
charpos=(400,500)
charpos1=(400,500)
campos=(0,0)
campos1=(0,0)
axis='x'
i=920
i1=0
isjump=True

while True:
	fps=clock.get_fps()
	events=py.event.get()
	for event in events:
		if event==py.QUIT:
			py.quit()
			exit()
			
	if page==0:
		sc.blit(bg,(0,0))
		Button.show()
		Button1.show()
		text('Start','Black',670,220,50)
		text('Settings','Black',640,290,50)
		text1('GEOMETRY DASH.exe','Green',540,100,100)
		introfloor.show()
		introfloor1.show()
		introChar.show((300,400))
#		introLight.show((300,400))
		if Button.ispressed:
			page=1
		
	if page==1:
		sc.blit(bg2,(0,0))
		
		floor.update((0,500-campos1[1]))
		floor.show()
		floor1.update((0,500-campos1[1]))
		floor1.show()
		floor2.update((700+campos1[0],300-campos1[1]))
		floor2.show()
		floor3.update((1800+campos1[0],100-campos1[1]))
		floor3.show()
		floor4.update((2800+campos1[0],300-campos1[1]))
		floor4.show()
		wall.update((-900+campos1[0],-500-campos1[1]))
		wall.show()
		wall1.update((0+campos1[0],-500-campos1[1]))
		wall1.show()
		wall2.update((2100+campos1[0],100-campos1[1]))
		wall2.show()
		Sign.show((950+campos1[0],300-campos1[1]))
		charpos1=(charpos[0]+campos1[0],charpos[1]-campos1[1])
		Char.show(charpos1)
		#light
#		CharLight.show(charpos1)
		jumpBut.show()
		Joystick.update(events)
		colrectY.update(charpos1)
		if Joystick.bobo:
			colrect.update(charpos1)
			if collide(colrect,CollideGroup)==False:
				charpos=(charpos[0]+Joystick.cos*12,charpos[1])
			if Joystick.cos>0:
				axis='x'
			elif Joystick.cos<0:
				axis='-x'
		if axis=='x':
			i1=0
			campos1=(campos[0]-charpos[0]+i,campos[1])
			if i>=500:
				i-=60
		elif axis=='-x':
			i=920
			campos1=(campos[0]-charpos[0]+500+i1,campos[1])
			if i1<420:
				i1+=60
		if charpos[1]<=300 and campos[1]>=0:
			campos1=(campos1[0],campos[1]-300+charpos[1])
		if jumpBut.isdown and isjump:
			vel=(vel[0],vel[1]+18)
			isjump=False
		else:
			if collide(colrectY,CollideGroup):
				isjump=True
				if vel[1]>0 or vel[1]<0:
					charpos=(charpos[0],charpos[1]+vel[1])
					vel=(vel[0],-vel[1]*0.2)
			if vel[1]!=-vel[1]*0.2:
				vel=(vel[0],vel[1]-grav/fps)
		charpos=(charpos[0]+vel[0],charpos[1]-vel[1])
		
	if fps>=30:
		text(f'fps:{round(fps)}','Green',1350,0,30)
	else:
		text(f'fps:{round(fps)}','Red',1350,0,30)
	py.display.update()
	clock.tick(60)