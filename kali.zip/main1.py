import pygame as pg
import math as m
import numpy as np
import win32gui, win32con
import random as rand
pg.init()
class Body:
    def __init__(self, height, type='body'):
        if type == 'body':
            self.image = pg.image.load('kali.png').convert()
            size = self.image.get_size()
            self.image = pg.transform.scale(self.image, (round(size[0]*(height/size[0])), height))
            self.image.set_colorkey('black')
            size = self.image.get_size()
            self.rimage = pg.transform.flip(self.image, True, False)
            self.surface = pg.surface.Surface((size[0]*2,size[1]), pg.SRCALPHA)
            self.surface.blit(self.rimage, (0,0))
            self.surface.blit(self.image, (size[0],0))
        else:    
            self.image = pg.image.load('head.png').convert()
            size = self.image.get_size()
            self.surface = pg.transform.scale(self.image, (round(size[0]*(height/size[0])), height))
            self.surface.set_colorkey('black')
    def draw(self, surface, position, angle):
        surf = pg.transform.rotate(self.surface, angle)
        rect = surf.get_rect(center = position)
        surface.blit(surf, rect)
def lerp(p, p1, t):
    p2 = [(p[0]*t+p1[0]*(1-t)), (p[1]*t+p1[1]*(1-t))]
    return p2
class Dragon:
    def __init__(self):
        count = 20
        self.points = [[-500,-500]]*count
        self.images = []
        for i in range(count-1):
            body = Body(100-i*5, 'head' if i==0 else 'body')
            self.images.append(body)
        self.angles = []
        self.pos = []
        self.target = [WIDTH/2,HEIGHT/2]
        self.dis = (50, 2.5)
        self.count = 0
        self.speed = 5
        self.angle = 0
        self.poss = [0,0]
    def move(self, position):
        self.points[0] = position
    def update(self, fps):
        self.angles = []
        self.pos = []
        for i in range(len(self.points)-1):
            difference = np.subtract(self.points[i], self.points[i+1])
            distance = (difference[0]**2+difference[1]**2)**.5
            rad = m.atan2(difference[1], difference[0])
            if distance > self.dis[0]-i*self.dis[1]:
                self.points[i+1] = np.subtract(self.points[i], np.multiply(self.dis[0]-i*self.dis[1], (m.cos(rad), m.sin(rad))))
            self.angles.append(360 - rad*180/m.pi - 90)
            self.pos.append(lerp(self.points[i], self.points[i+1], .5))
        self.points[0] = self.poss
        dl = (np.sum(np.square(np.subtract(self.poss,self.target))))**.5
        if dl < 10:
            self.target = [rand.random()*WIDTH,rand.random()*HEIGHT]
            self.count = 0
        self.count += 1/fps
        self.angle = m.atan2(self.target[1]-self.poss[1]+(self.target[1]-(self.poss[1]+dl*m.cos(self.angle))),self.target[0]-self.poss[0]+(self.target[0]-(self.poss[0]+dl*m.sin(self.angle))))
        self.poss = np.add(self.poss,np.multiply(self.speed,(m.cos(self.angle),m.sin(self.angle))))
    def draw(self, surface):
        for i in range(len(self.images)):
            self.images[i].draw(surface, self.pos[i], self.angles[i])
WIDTH, HEIGHT = pg.display.Info().current_w, pg.display.Info().current_h
screen = pg.display.set_mode((WIDTH,HEIGHT), pg.NOFRAME)
clock = pg.time.Clock()
window_id = pg.display.get_wm_info()['window']
win32gui.SetWindowLong(window_id, win32con.GWL_EXSTYLE,
                       win32con.WS_EX_LAYERED | win32con.WS_EX_TOPMOST)
win32gui.SetLayeredWindowAttributes(window_id, 0, 0, win32con.LWA_COLORKEY)
win32gui.SetWindowPos(window_id, win32con.HWND_TOPMOST, 0, 0, 0, 0, win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
dragon = Dragon()
running = True
while running:
    pg.event.pump()
    fps = clock.get_fps()
    fps = fps if fps != 0 else 60
    for e in pg.event.get():
        if e.type == pg.QUIT:
            running = False
    screen.fill((0, 0, 0))
    dragon.update(fps)
    dragon.draw(screen)
    pg.display.update()
    win32gui.SetWindowPos(window_id, win32con.HWND_TOPMOST, 0, 0, 0, 0, win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
    clock.tick(120)
pg.quit()
exit()






