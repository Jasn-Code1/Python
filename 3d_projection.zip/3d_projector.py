import pygame as py
import numpy as np
import random as rand
from math import *
from sys import exit

py.init()

def text(t,c,pos,s):
	font=py.font.Font(None,s)
	text=font.render(t,True,c)
	sc.blit(text,pos)

points=[]

for i in range(8):
	x=cos(floor(i/4)*pi)
	y=cos(floor(i/2)*pi)
	z=cos(floor(i/2+.5)*pi)
	points.append([int(x),int(y),int(z)])

proj2d=[
[1,0,0],
[0,1,0],
[0,0,0]
]

sc=py.display.set_mode((0,0),py.FULLSCREEN)
w,h=sc.get_size()
clock=py.time.Clock()
offset=[w/2,h/2,0]
scale=100
p=1
ax=0
ay=0
az=0
rot_sen=3
ic1=0
ic2=0
ic3=0
dc1=1
dc2=2
dc3=4
while True:
	event=py.event.get()
	for e in event:
		if e==py.QUIT:
			py.quit()
			exit()
	
	if p==1:
		if e.type==py.FINGERMOTION:
			if az==pi:
				ay-=e.dx*rot_sen
				ax+=e.dy*rot_sen
			else:
				ay+=e.dx*rot_sen
				ax-=e.dy*rot_sen
		if ax>=pi:
			ax-=2*pi
		elif ax<=-pi:
			ax+=2*pi
		if ay>=pi:
			ay-=2*pi
		elif ay<=-pi:
			ay+=2*pi
			
		if abs(ax)>pi/2:
			if az==pi:
				az=0
			else:
				az=pi
			ay=ay+pi
			if ax>0:
				ax-=ax-pi/2
			else:
				ax-=ax+pi/2
		
		sc.fill('Black')
		
		pointslist=[]
		
		rotate_x=[
		[1,0,0],
		[0,cos(ax),-sin(ax)],
		[0,sin(ax),cos(ax)],
		]
		rotate_y=[
		[cos(ay),0,sin(ay)],
		[0,1,0],
		[-sin(ay),0,cos(ay)],
		]
		rotate_z=[
		[cos(az),-sin(az),0],
		[sin(az),cos(az),0],
		[0,0,1]
		]
		
		for point in points:
			rotated=np.dot(rotate_y,point)
			rotated=np.dot(rotate_x,rotated)
			rotated=np.dot(rotate_z,rotated)
			projected=np.dot(proj2d,rotated)
			scaled=np.multiply(projected,scale)
			repossitioned=np.add(scaled,offset)
#			py.draw.circle(sc,'Red',repossitioned[:2],5)
			pointslist.append(repossitioned[:2])
		
		if abs(ax+pi/2)<pi/2:
			py.draw.polygon(sc,'White',pointslist[2:4]+pointslist[::-1][:2])
		if abs(ax-pi/2)<pi/2:
			py.draw.polygon(sc,'Yellow',pointslist[:2]+pointslist[::-1][2:4])
		if abs(ax)<pi/2 and abs(ay+pi/2)<pi/2:
			py.draw.polygon(sc,'Green',pointslist[:4])
		if abs(ax)<pi/2 and abs(ay)<pi/2:
			py.draw.polygon(sc,'Orange',pointslist[::3][:2]+pointslist[::-3][:2])
		if abs(ax)<pi/2 and abs(ay-pi/2)<pi/2:
			py.draw.polygon(sc,'Blue',pointslist[4:7]+pointslist[::-3][:2])
		if abs(ax)<pi/2 and (abs(ay+pi)<pi/2 or abs(ay-pi)<pi/2):
			py.draw.polygon(sc,'Red',pointslist[1:3]+pointslist[::-1][1:3])
		
		ic1+=dc1
		ic2+dc2
		ic3+=dc3
		
		if ic1>255 or ic1<0:
			dc1=-dc1
			ic1+=dc1
		if ic2>255 or ic2<0:
			dc2=-dc2
			ic2+=dc2
		if ic3>255 or ic3<0:
			dc3=-dc3
			ic3+=dc3
		
		randcol=(ic1,ic2,ic3)
		
		for i in range(4):
			if i==3:
				i1=-3
			else:
				i1=1
			py.draw.line(sc,randcol,pointslist[i],pointslist[i+4],3)
			py.draw.line(sc,randcol,pointslist[i],pointslist[i+i1],3)
			py.draw.line(sc,randcol,pointslist[i+4],pointslist[i+i1+4],3)
	fps=clock.get_fps()
	text(str(round(fps)),(0,255,0),(10,10),30)
	py.display.update()
	clock.tick(60)